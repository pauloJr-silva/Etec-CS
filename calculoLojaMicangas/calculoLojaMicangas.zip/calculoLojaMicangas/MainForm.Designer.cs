﻿/*
 * Created by SharpDevelop.
 * User: Aluno Etec
 * Date: 17/08/2023
 * Time: 20:20
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
namespace calculoLojaMicangas
{
	partial class MainForm
	{
		/// <summary>
		/// Designer variable used to keep track of non-visual components.
		/// </summary>
		private System.ComponentModel.IContainer components = null;
		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.Label label2;
		private System.Windows.Forms.Label label3;
		private System.Windows.Forms.Label label4;
		private System.Windows.Forms.Label label5;
		private System.Windows.Forms.Label label6;
		private System.Windows.Forms.TextBox textBox1;
		private System.Windows.Forms.TextBox textBox2;
		private System.Windows.Forms.TextBox textBox3;
		private System.Windows.Forms.TextBox textBox4;
		private System.Windows.Forms.TextBox textBox5;
		private System.Windows.Forms.TextBox textBox6;
		private System.Windows.Forms.Button button1;
		private System.Windows.Forms.Label label7;
		private System.Windows.Forms.TextBox textBox7;
		private System.Windows.Forms.TextBox textBox8;
		private System.Windows.Forms.TextBox textBox9;
		private System.Windows.Forms.Label label8;
		private System.Windows.Forms.TextBox textBox10;
		private System.Windows.Forms.TextBox textBox11;
		private System.Windows.Forms.TextBox textBox12;
		private System.Windows.Forms.TextBox textBox13;
		private System.Windows.Forms.TextBox textBox14;
		private System.Windows.Forms.TextBox textBox15;
		private System.Windows.Forms.Label label9;
		private System.Windows.Forms.Label label16;
		private System.Windows.Forms.TextBox textBox16;
		private System.Windows.Forms.TextBox textBox17;
		private System.Windows.Forms.Label label17;
		
		/// <summary>
		/// Disposes resources used by the form.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing) {
				if (components != null) {
					components.Dispose();
				}
			}
			base.Dispose(disposing);
		}
		
		/// <summary>
		/// This method is required for Windows Forms designer support.
		/// Do not change the method contents inside the source code editor. The Forms designer might
		/// not be able to load this method if it was changed manually.
		/// </summary>
		private void InitializeComponent()
		{
			this.label2 = new System.Windows.Forms.Label();
			this.label3 = new System.Windows.Forms.Label();
			this.label4 = new System.Windows.Forms.Label();
			this.label5 = new System.Windows.Forms.Label();
			this.label6 = new System.Windows.Forms.Label();
			this.textBox1 = new System.Windows.Forms.TextBox();
			this.textBox2 = new System.Windows.Forms.TextBox();
			this.textBox3 = new System.Windows.Forms.TextBox();
			this.textBox4 = new System.Windows.Forms.TextBox();
			this.textBox5 = new System.Windows.Forms.TextBox();
			this.textBox6 = new System.Windows.Forms.TextBox();
			this.label1 = new System.Windows.Forms.Label();
			this.button1 = new System.Windows.Forms.Button();
			this.label7 = new System.Windows.Forms.Label();
			this.textBox7 = new System.Windows.Forms.TextBox();
			this.textBox8 = new System.Windows.Forms.TextBox();
			this.textBox9 = new System.Windows.Forms.TextBox();
			this.label8 = new System.Windows.Forms.Label();
			this.textBox10 = new System.Windows.Forms.TextBox();
			this.textBox11 = new System.Windows.Forms.TextBox();
			this.textBox12 = new System.Windows.Forms.TextBox();
			this.textBox13 = new System.Windows.Forms.TextBox();
			this.textBox14 = new System.Windows.Forms.TextBox();
			this.textBox15 = new System.Windows.Forms.TextBox();
			this.label9 = new System.Windows.Forms.Label();
			this.label16 = new System.Windows.Forms.Label();
			this.textBox16 = new System.Windows.Forms.TextBox();
			this.textBox17 = new System.Windows.Forms.TextBox();
			this.label17 = new System.Windows.Forms.Label();
			this.SuspendLayout();
			// 
			// label2
			// 
			this.label2.Location = new System.Drawing.Point(173, 29);
			this.label2.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
			this.label2.Name = "label2";
			this.label2.Size = new System.Drawing.Size(75, 19);
			this.label2.TabIndex = 1;
			this.label2.Text = "Estoque Final";
			// 
			// label3
			// 
			this.label3.Location = new System.Drawing.Point(9, 30);
			this.label3.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
			this.label3.Name = "label3";
			this.label3.Size = new System.Drawing.Size(75, 19);
			this.label3.TabIndex = 2;
			this.label3.Text = "Produto";
			// 
			// label4
			// 
			this.label4.Location = new System.Drawing.Point(11, 59);
			this.label4.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
			this.label4.Name = "label4";
			this.label4.Size = new System.Drawing.Size(49, 19);
			this.label4.TabIndex = 3;
			this.label4.Text = "C1";
			// 
			// label5
			// 
			this.label5.Location = new System.Drawing.Point(11, 93);
			this.label5.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
			this.label5.Name = "label5";
			this.label5.Size = new System.Drawing.Size(49, 19);
			this.label5.TabIndex = 4;
			this.label5.Text = "C2";
			// 
			// label6
			// 
			this.label6.Location = new System.Drawing.Point(11, 129);
			this.label6.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
			this.label6.Name = "label6";
			this.label6.Size = new System.Drawing.Size(49, 19);
			this.label6.TabIndex = 5;
			this.label6.Text = "C3";
			// 
			// textBox1
			// 
			this.textBox1.Font = new System.Drawing.Font("Arial Narrow", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.textBox1.Location = new System.Drawing.Point(75, 50);
			this.textBox1.Margin = new System.Windows.Forms.Padding(2);
			this.textBox1.Name = "textBox1";
			this.textBox1.Size = new System.Drawing.Size(76, 25);
			this.textBox1.TabIndex = 6;
			this.textBox1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
			// 
			// textBox2
			// 
			this.textBox2.Font = new System.Drawing.Font("Arial Narrow", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.textBox2.Location = new System.Drawing.Point(75, 91);
			this.textBox2.Margin = new System.Windows.Forms.Padding(2);
			this.textBox2.Name = "textBox2";
			this.textBox2.Size = new System.Drawing.Size(76, 25);
			this.textBox2.TabIndex = 7;
			this.textBox2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
			// 
			// textBox3
			// 
			this.textBox3.Font = new System.Drawing.Font("Arial Narrow", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.textBox3.Location = new System.Drawing.Point(75, 125);
			this.textBox3.Margin = new System.Windows.Forms.Padding(2);
			this.textBox3.Name = "textBox3";
			this.textBox3.Size = new System.Drawing.Size(76, 25);
			this.textBox3.TabIndex = 8;
			this.textBox3.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
			// 
			// textBox4
			// 
			this.textBox4.Font = new System.Drawing.Font("Arial Narrow", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.textBox4.Location = new System.Drawing.Point(173, 52);
			this.textBox4.Margin = new System.Windows.Forms.Padding(2);
			this.textBox4.Name = "textBox4";
			this.textBox4.Size = new System.Drawing.Size(76, 25);
			this.textBox4.TabIndex = 9;
			this.textBox4.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
			// 
			// textBox5
			// 
			this.textBox5.Font = new System.Drawing.Font("Arial Narrow", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.textBox5.Location = new System.Drawing.Point(173, 89);
			this.textBox5.Margin = new System.Windows.Forms.Padding(2);
			this.textBox5.Name = "textBox5";
			this.textBox5.Size = new System.Drawing.Size(76, 25);
			this.textBox5.TabIndex = 10;
			this.textBox5.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
			// 
			// textBox6
			// 
			this.textBox6.Font = new System.Drawing.Font("Arial Narrow", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.textBox6.Location = new System.Drawing.Point(173, 125);
			this.textBox6.Margin = new System.Windows.Forms.Padding(2);
			this.textBox6.Name = "textBox6";
			this.textBox6.Size = new System.Drawing.Size(76, 25);
			this.textBox6.TabIndex = 11;
			this.textBox6.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
			// 
			// label1
			// 
			this.label1.Location = new System.Drawing.Point(75, 30);
			this.label1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(75, 19);
			this.label1.TabIndex = 12;
			this.label1.Text = "Estoque Inicial";
			// 
			// button1
			// 
			this.button1.Location = new System.Drawing.Point(75, 162);
			this.button1.Margin = new System.Windows.Forms.Padding(2);
			this.button1.Name = "button1";
			this.button1.Size = new System.Drawing.Size(138, 43);
			this.button1.TabIndex = 13;
			this.button1.Text = "calcular";
			this.button1.UseVisualStyleBackColor = true;
			this.button1.Click += new System.EventHandler(this.Button1Click);
			// 
			// label7
			// 
			this.label7.Location = new System.Drawing.Point(269, 30);
			this.label7.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
			this.label7.Name = "label7";
			this.label7.Size = new System.Drawing.Size(75, 19);
			this.label7.TabIndex = 14;
			this.label7.Text = "Qtd Vendida";
			// 
			// textBox7
			// 
			this.textBox7.Enabled = false;
			this.textBox7.Font = new System.Drawing.Font("Arial Narrow", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.textBox7.Location = new System.Drawing.Point(269, 52);
			this.textBox7.Margin = new System.Windows.Forms.Padding(2);
			this.textBox7.Name = "textBox7";
			this.textBox7.Size = new System.Drawing.Size(76, 25);
			this.textBox7.TabIndex = 15;
			this.textBox7.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
			// 
			// textBox8
			// 
			this.textBox8.Enabled = false;
			this.textBox8.Font = new System.Drawing.Font("Arial Narrow", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.textBox8.Location = new System.Drawing.Point(269, 87);
			this.textBox8.Margin = new System.Windows.Forms.Padding(2);
			this.textBox8.Name = "textBox8";
			this.textBox8.Size = new System.Drawing.Size(76, 25);
			this.textBox8.TabIndex = 16;
			this.textBox8.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
			// 
			// textBox9
			// 
			this.textBox9.Enabled = false;
			this.textBox9.Font = new System.Drawing.Font("Arial Narrow", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.textBox9.Location = new System.Drawing.Point(269, 122);
			this.textBox9.Margin = new System.Windows.Forms.Padding(2);
			this.textBox9.Name = "textBox9";
			this.textBox9.Size = new System.Drawing.Size(76, 25);
			this.textBox9.TabIndex = 17;
			this.textBox9.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
			// 
			// label8
			// 
			this.label8.Location = new System.Drawing.Point(376, 29);
			this.label8.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
			this.label8.Name = "label8";
			this.label8.Size = new System.Drawing.Size(75, 19);
			this.label8.TabIndex = 18;
			this.label8.Text = "Valor Total ($)";
			// 
			// textBox10
			// 
			this.textBox10.Enabled = false;
			this.textBox10.Font = new System.Drawing.Font("Arial Narrow", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.textBox10.Location = new System.Drawing.Point(376, 123);
			this.textBox10.Margin = new System.Windows.Forms.Padding(2);
			this.textBox10.Name = "textBox10";
			this.textBox10.Size = new System.Drawing.Size(76, 25);
			this.textBox10.TabIndex = 21;
			this.textBox10.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
			// 
			// textBox11
			// 
			this.textBox11.Enabled = false;
			this.textBox11.Font = new System.Drawing.Font("Arial Narrow", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.textBox11.Location = new System.Drawing.Point(376, 87);
			this.textBox11.Margin = new System.Windows.Forms.Padding(2);
			this.textBox11.Name = "textBox11";
			this.textBox11.Size = new System.Drawing.Size(76, 25);
			this.textBox11.TabIndex = 20;
			this.textBox11.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
			// 
			// textBox12
			// 
			this.textBox12.Enabled = false;
			this.textBox12.Font = new System.Drawing.Font("Arial Narrow", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.textBox12.Location = new System.Drawing.Point(376, 52);
			this.textBox12.Margin = new System.Windows.Forms.Padding(2);
			this.textBox12.Name = "textBox12";
			this.textBox12.Size = new System.Drawing.Size(76, 25);
			this.textBox12.TabIndex = 19;
			this.textBox12.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
			// 
			// textBox13
			// 
			this.textBox13.Enabled = false;
			this.textBox13.Font = new System.Drawing.Font("Arial Narrow", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.textBox13.Location = new System.Drawing.Point(488, 123);
			this.textBox13.Margin = new System.Windows.Forms.Padding(2);
			this.textBox13.Name = "textBox13";
			this.textBox13.Size = new System.Drawing.Size(76, 25);
			this.textBox13.TabIndex = 25;
			this.textBox13.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
			// 
			// textBox14
			// 
			this.textBox14.Enabled = false;
			this.textBox14.Font = new System.Drawing.Font("Arial Narrow", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.textBox14.Location = new System.Drawing.Point(488, 87);
			this.textBox14.Margin = new System.Windows.Forms.Padding(2);
			this.textBox14.Name = "textBox14";
			this.textBox14.Size = new System.Drawing.Size(76, 25);
			this.textBox14.TabIndex = 24;
			this.textBox14.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
			// 
			// textBox15
			// 
			this.textBox15.Enabled = false;
			this.textBox15.Font = new System.Drawing.Font("Arial Narrow", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.textBox15.Location = new System.Drawing.Point(488, 52);
			this.textBox15.Margin = new System.Windows.Forms.Padding(2);
			this.textBox15.Name = "textBox15";
			this.textBox15.Size = new System.Drawing.Size(76, 25);
			this.textBox15.TabIndex = 23;
			this.textBox15.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
			// 
			// label9
			// 
			this.label9.Location = new System.Drawing.Point(480, 29);
			this.label9.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
			this.label9.Name = "label9";
			this.label9.Size = new System.Drawing.Size(94, 19);
			this.label9.TabIndex = 22;
			this.label9.Text = "Lucro por Item ($)";
			// 
			// label16
			// 
			this.label16.Font = new System.Drawing.Font("Arial Narrow", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label16.Location = new System.Drawing.Point(395, 160);
			this.label16.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
			this.label16.Name = "label16";
			this.label16.Size = new System.Drawing.Size(95, 19);
			this.label16.TabIndex = 32;
			this.label16.Text = "Venda Total:";
			// 
			// textBox16
			// 
			this.textBox16.Enabled = false;
			this.textBox16.Font = new System.Drawing.Font("Arial Narrow", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.textBox16.Location = new System.Drawing.Point(488, 160);
			this.textBox16.Margin = new System.Windows.Forms.Padding(2);
			this.textBox16.Name = "textBox16";
			this.textBox16.Size = new System.Drawing.Size(76, 25);
			this.textBox16.TabIndex = 33;
			this.textBox16.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
			// 
			// textBox17
			// 
			this.textBox17.Enabled = false;
			this.textBox17.Font = new System.Drawing.Font("Arial Narrow", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.textBox17.Location = new System.Drawing.Point(488, 187);
			this.textBox17.Margin = new System.Windows.Forms.Padding(2);
			this.textBox17.Name = "textBox17";
			this.textBox17.Size = new System.Drawing.Size(76, 25);
			this.textBox17.TabIndex = 35;
			this.textBox17.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
			// 
			// label17
			// 
			this.label17.Font = new System.Drawing.Font("Arial Narrow", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label17.Location = new System.Drawing.Point(395, 187);
			this.label17.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
			this.label17.Name = "label17";
			this.label17.Size = new System.Drawing.Size(89, 19);
			this.label17.TabIndex = 34;
			this.label17.Text = "Lucro Total:";
			// 
			// MainForm
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.ClientSize = new System.Drawing.Size(585, 229);
			this.Controls.Add(this.textBox17);
			this.Controls.Add(this.label17);
			this.Controls.Add(this.textBox16);
			this.Controls.Add(this.label16);
			this.Controls.Add(this.textBox13);
			this.Controls.Add(this.textBox14);
			this.Controls.Add(this.textBox15);
			this.Controls.Add(this.label9);
			this.Controls.Add(this.textBox10);
			this.Controls.Add(this.textBox11);
			this.Controls.Add(this.textBox12);
			this.Controls.Add(this.label8);
			this.Controls.Add(this.textBox9);
			this.Controls.Add(this.textBox8);
			this.Controls.Add(this.textBox7);
			this.Controls.Add(this.label7);
			this.Controls.Add(this.button1);
			this.Controls.Add(this.label1);
			this.Controls.Add(this.textBox6);
			this.Controls.Add(this.textBox5);
			this.Controls.Add(this.textBox4);
			this.Controls.Add(this.textBox3);
			this.Controls.Add(this.textBox2);
			this.Controls.Add(this.textBox1);
			this.Controls.Add(this.label6);
			this.Controls.Add(this.label5);
			this.Controls.Add(this.label4);
			this.Controls.Add(this.label3);
			this.Controls.Add(this.label2);
			this.Margin = new System.Windows.Forms.Padding(2);
			this.Name = "MainForm";
			this.ResumeLayout(false);
			this.PerformLayout();

		}
	}
}
